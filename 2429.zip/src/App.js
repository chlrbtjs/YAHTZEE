import './App.css';
import Diceblock from './components/diceblock';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Diceblock></Diceblock>
      </header>
    </div>
  );
}

export default App;
